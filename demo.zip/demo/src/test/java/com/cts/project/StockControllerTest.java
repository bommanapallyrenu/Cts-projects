package com.cts.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.project.controller.CompanyController;
import com.cts.project.controller.StockController;
import com.cts.project.entity.Company;
import com.cts.project.entity.Stock;
import com.cts.project.service.CompanyServiceImpl;
import com.cts.project.service.StockServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;



@AutoConfigureMockMvc
@SpringBootTest
public class StockControllerTest 
{
			@Mock
			private CompanyServiceImpl companyService;
			
			@Mock
			private StockServiceImpl stockService;
			
			@InjectMocks
			private StockController stockControllerobj;
			
			@Autowired
			private MockMvc mockMvc;
			
			
			@BeforeEach
			public void init()
			{
				MockitoAnnotations.openMocks(this);
				mockMvc = MockMvcBuilders.standaloneSetup(stockControllerobj).build();
			}

			Set<Stock> stockList = new HashSet<Stock>();
			
			@Test
			public void getAllStockSuccess() throws Exception
			{
				Stock stock=new Stock();
				stock.setCompany_code_fk(125);
				//stock.setDate_time(new Date("2022-10-27T15:03:34"));
				stock.setStockPrice(12.5);
				
				stockList.add(stock);
				when(stockService.getAllStocks(125)).thenReturn((Set<Stock>) stockList);
				
				Set<Stock> uList =stockService.getAllStocks(125);
				assertEquals(stockList, uList);
				
		mockMvc.perform(MockMvcRequestBuilders.get("/api/v1.0/market/stock/getAllStocks").param("companycode", "125").contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
				
			}
			
			@Test
			public void getAllStockFailure() throws Exception
			{
				stockList.clear();
				when(stockService.getAllStocks(125)).thenReturn((Set<Stock>) stockList);
				System.out.println(stockList);
				assertEquals(0,stockList.size());
				
				mockMvc.perform(MockMvcRequestBuilders.get("/api/v1.0/market/stock/getAllStocks").param("companycode", "102").contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isNoContent());
				
			}
			
			@Test
			public void addStockSuccess() throws Exception
			{
				int companycode=125;
				Stock stock=new Stock();
				stock.setCompany_code_fk(125);
				//stock.setDate_time(new Date(""));
				stock.setStockPrice(12.5);
				
				stockList.add(stock);
				when(stockService.addStock(any())).thenReturn(true);
				
				
				assertEquals(1,stockList.size());
				
		mockMvc.perform(MockMvcRequestBuilders.post("/api/v1.0/market/stock/add/{companycode}",125).contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(stock))).andExpect(MockMvcResultMatchers.status().isCreated());
				
				
		mockMvc.perform(MockMvcRequestBuilders.post("/api/v1.0/market/stock/add/102"))
				.andExpect(status().isCreated())
				.andExpect(content().string("ok"));
			}
			
			@Test
			public void addStockFailure() throws Exception
			{
				
				when(stockService.addStock(any())).thenReturn(false);
				
				Stock stock=new Stock();
				
				boolean val = stockService.addStock(stock);
				
				assertFalse(val);
				
		mockMvc.perform(MockMvcRequestBuilders.post("/api/v1.0/market/stock/add/125").contentType(MediaType.APPLICATION_JSON)
		.content(new ObjectMapper().writeValueAsString(null))).andExpect(MockMvcResultMatchers.status().is4xxClientError());

				
			}

		}

