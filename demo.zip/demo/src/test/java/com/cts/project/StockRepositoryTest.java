package com.cts.project;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

import com.cts.project.Repository.StockRepository;
import com.cts.project.entity.Stock;


@DataJpaTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)

public class StockRepositoryTest
{
	@Autowired
	private StockRepository stockRepo;
	
	private Stock stock = new Stock();// real object
	
	@BeforeEach
	public void init()
	{
		stock.setTransactionId(1);
		stock.setCompany_code_fk(125);;
		stock.setStockPrice(12.5);
		stock.setDate_time(null);
	}
	
	@Test
	public void getStocksSuccess() throws Exception
	{
		Stock stock1 = null;
		
		stockRepo.save(stock);
		
		Set<Stock> stocklist=stockRepo.getStockList(125);
		
		System.out.println(stock.getCompany_code_fk());
		
		stock1 = stockRepo.findById(stock.getTransactionId()).get();
		
		assertEquals(stock.getStockPrice(), stock1.getStockPrice());
		
		assertEquals(1, stocklist.size());
		
	}
	
	@Test
	public void getStocksFailure() throws Exception
	{
	
		Set<Stock> stocklist=stockRepo.getStockList(125); //didn't save stock data returns null 
		
		if(stockRepo.findAll().toString().isEmpty())
		{
			stockRepo.save(stock);
			
		}
		assertEquals(0, stocklist.size());
		
	}

}