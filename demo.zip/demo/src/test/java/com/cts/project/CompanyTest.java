package com.cts.project;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.cts.project.entity.Company;
import com.cts.project.entity.Stock;


public class CompanyTest {
		
		
		@Test
		public void test01()
		{
			Company companyObj = Mockito.mock(Company.class);// creating the mock object
			
			when(companyObj.getCompanyName()).thenReturn(null);
			
			Company company = new Company();
			
			company.setCompanyName("Cognizant");
				 
			String companyname = company.getCompanyName();
			 
			 when(companyObj.getCompanyName()).thenReturn("Cognizant");
				 
			 assertEquals("Cognizant", companyname);
			
		}
	}
