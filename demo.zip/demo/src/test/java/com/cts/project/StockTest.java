package com.cts.project;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.cts.project.entity.Stock;


public class StockTest {
		
		@Test
		public void test01()
		{
			Stock stockObj = Mockito.mock(Stock.class);// creating the mock object
			
			when(stockObj.getStockPrice()).thenReturn(null);
			
			Stock stock = new Stock();
			
			stock.setStockPrice(12.5);
			
			Double stockprice=stock.getStockPrice();
			 
			 when(stockObj.getStockPrice()).thenReturn(12.5);
		
			 
			 assertEquals(12.5, stockprice);
			
			
		}

	}
