package com.cts.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import static org.mockito.Mockito.any;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.project.Repository.CompanyRepository;
import com.cts.project.entity.Company;
import com.cts.project.service.CompanyServiceImpl;

@AutoConfigureMockMvc
@SpringBootTest
public class CompanyServiceImplTest 
{
		@Mock
		private CompanyRepository companyRepo;
		
		@InjectMocks
		private CompanyServiceImpl companyService;
		
		@Autowired
		private MockMvc mockMvc;
		
		@BeforeEach
		public void init()
		{
			MockitoAnnotations.openMocks(this);
			mockMvc = MockMvcBuilders.standaloneSetup(companyService).build();
		}

		List<Company> companyList = new ArrayList<Company>();
		
		@Test
		public void getAllCompanySuccess() throws Exception
		{
			Company company = new Company();
			company.setCompanyCEO("CEO");
			company.setCompanyName("Cognizant");
			company.setCompanyWebsite("www.cognizant.com");
			company.setStockEnlistmentSite("NSE");
			company.setCompanyCode(125);
			
			companyList.add(company);
			when(companyRepo.findAll()).thenReturn(companyList);
			
			List<Company> newList = companyService.getAllCompanies();
			assertEquals(companyList, newList);
			
		}
		
		@Test
		public void getAllCompanyFailure() throws Exception
		{
			
			when(companyRepo.findAll()).thenReturn(null);
			
			List<Company> companyList = companyService.getAllCompanies();
			assertNull(companyList);
			
		}
		
		@Test
		public void addCompanySuccess() throws Exception
		{
			Company company = new Company();
			company.setCompanyCEO("CEO");
			company.setCompanyName("Cognizant");
			company.setCompanyWebsite("www.cognizant.com");
			company.setStockEnlistmentSite("NSE");
			company.setCompanyCode(125);
			
			companyList.add(company);
			when(companyRepo.save(any())).thenReturn(company);
			
			Company c1 = companyService.save(company);
			assertEquals(company, c1);
			
		}
		
		@Test
		public void addCompanyFailure() throws Exception
		{
			
			when(companyRepo.save(any())).thenReturn(null);
			Company company = new Company(); //empty object
			
			Company c1 = companyService.save(company);
			assertNull(c1);
			
		}

}
