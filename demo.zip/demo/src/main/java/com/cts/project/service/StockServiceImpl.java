package com.cts.project.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.project.Repository.StockRepository;
import com.cts.project.entity.Stock;

@Service
public class StockServiceImpl implements StockService{
	
	@Autowired
	private StockRepository stockrepo;
	
	@Override
	public Set<Stock> getAllStocks(int companyCode){
	 
		Set<Stock> readerList = stockrepo.getStockList(companyCode);
		return readerList;
	 
	}
	
	@Override
	public boolean deleteStock(int Companycode) {
		
		stockrepo.deleteStockData(Companycode);
		return true;
		
	}
	
	@Override
	public boolean addStock(Stock stock) {
		
		if(stock!=null) {
			stockrepo.save(stock);
			return true;
		}
		return false;
			
	}
}
