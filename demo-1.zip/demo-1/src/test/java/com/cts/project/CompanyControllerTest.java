package com.cts.project;


import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.project.Repository.CompanyRepository;
import com.cts.project.controller.CompanyController;
import com.cts.project.entity.Company;
import com.cts.project.service.CompanyServiceImpl;
import com.cts.project.service.StockServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;



@AutoConfigureMockMvc
@SpringBootTest
public class CompanyControllerTest 
{
		@Mock
		private CompanyServiceImpl companyService;
		
		@Mock
		private CompanyRepository companyRepo;
		@Mock
		private StockServiceImpl stockService;
		
		@InjectMocks
		private CompanyController companyControllerobj;
		
		@Autowired
		private MockMvc mockMvc;
		
		
		@BeforeEach
		public void init()
		{
			MockitoAnnotations.openMocks(this);
			mockMvc = MockMvcBuilders.standaloneSetup(companyControllerobj).build();
		}

		List<Company> CompanyList = new ArrayList<Company>();
		
		@Test
		public void getAllCompanySuccess() throws Exception
		{
			Company company = new Company();
			company.setCompanyCEO("CEO");
			company.setCompanyName("Cognizant");
			company.setCompanyWebsite("www.cognizant.com");
			company.setStockEnlistmentSite("NSE");
			company.setCompanyCode(125);
			
			CompanyList.add(company);
			when(companyService.getAllCompanies()).thenReturn(CompanyList);
			
			List<Company> uList = companyService.getAllCompanies();
			assertEquals(CompanyList, uList);
			
	mockMvc.perform(MockMvcRequestBuilders.get("/api/v1.0/market/company/getall").contentType(MediaType.APPLICATION_JSON))
			.andExpect(MockMvcResultMatchers.status().isOk());
			
		}
		
		@Test
		public void getAllCompanyFailure() throws Exception
		{
			CompanyList.clear();
			when(companyService.getAllCompanies()).thenReturn(CompanyList);
			System.out.println(CompanyList);
			assertEquals(0,CompanyList.size());
			
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1.0/market/company/getall").contentType(MediaType.APPLICATION_JSON))
			.andExpect(MockMvcResultMatchers.status().isNoContent());
			
		}
		
		@Test
		public void addCompanySuccess() throws Exception
		{
			Company company = new Company();
			company.setCompanyCEO("CEO");
			company.setCompanyName("Cognizant");
			company.setCompanyWebsite("www.cognizant.com");
			company.setStockEnlistmentSite("NSE");
			company.setCompanyCode(125);
			
			CompanyList.add(company);
			when(companyService.save(any())).thenReturn(company);
			
			assertEquals(1,CompanyList.size());
	mockMvc.perform(MockMvcRequestBuilders.post("/api/v1.0/market/company/register").contentType(MediaType.APPLICATION_JSON)
			.content(new ObjectMapper().writeValueAsString(company))).andExpect(MockMvcResultMatchers.status().isCreated());
			
		}
		
		@Test
		public void addCompanyFailure() throws Exception
		{
			
			when(companyService.save(any())).thenReturn(null);
			
			Company c1 = companyService.save(null);
			assertNull(c1);
			
	mockMvc.perform(MockMvcRequestBuilders.post("/api/v1.0/market/company/register").contentType(MediaType.APPLICATION_JSON)
	.content(new ObjectMapper().writeValueAsString(c1))).andExpect(MockMvcResultMatchers.status().is4xxClientError());

			
		}
		
		@Test
		public void deletecompanySuccess() throws Exception{
			Company company = new Company();
			company.setCompanyCEO("CEO");
			company.setCompanyName("Cognizant");
			company.setCompanyWebsite("www.cognizant.com");
			company.setStockEnlistmentSite("NSE");
			company.setCompanyCode(125);
			
			 when(companyService.delete(company.getCompanyCode())).thenReturn(true);
			 when(stockService.deleteStock(company.getCompanyCode())).thenReturn(true);
			mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1.0/market/company/delete/{companycode}",125).contentType(MediaType.APPLICATION_JSON)
					.content(new ObjectMapper().writeValueAsString("Company Object Deleted Successfully"))).andExpect(MockMvcResultMatchers.status().isNoContent());

			
			
		}
		
		@Test
		public void deletecompanyFailure() throws Exception{
			
			Company company = new Company();
			company.setCompanyCEO("CEO");
			company.setCompanyName("Cognizant");
			company.setCompanyWebsite("www.cognizant.com");
			company.setStockEnlistmentSite("NSE");
			company.setCompanyCode(125);
			
			
			when(companyService.delete(125)).thenReturn(false);
			
			
			mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1.0/market/company/delete/{companycode}",125).contentType(MediaType.APPLICATION_JSON)
					.content(new ObjectMapper().writeValueAsString(""))).andExpect(MockMvcResultMatchers.status().isInternalServerError());

			
		}
		
		@Test
		public void updatecompanySuccess() throws Exception
		{	
			Company company = new Company();
			company.setCompanyCEO("CEO");
			company.setCompanyName("Cognizant");
			company.setCompanyWebsite("www.cognizant.com");
			company.setStockEnlistmentSite("NSE");
			company.setCompanyCode(125);
			
			
			Company newcompany = new Company();
			newcompany.setCompanyCEO("CEO");
			newcompany.setCompanyName("CTS");
			newcompany.setCompanyWebsite("www.cognizant.com");
			newcompany.setStockEnlistmentSite("NSE");
			newcompany.setCompanyCode(125);
			
			
			when(companyService.updateCompany(any())).thenReturn(true);
			
			mockMvc.perform(MockMvcRequestBuilders.put("/api/v1.0/market/company/put/{companycode}",125).contentType(MediaType.APPLICATION_JSON)
					.content(new ObjectMapper().writeValueAsString(newcompany))).andExpect(MockMvcResultMatchers.status().isCreated());
		
		}
		
		@Test
		public void updatecompanyFailure() throws Exception
		{
			Company company = new Company();
			company.setCompanyCEO("CEO");
			company.setCompanyName("Cognizant");
			company.setCompanyWebsite("www.cognizant.com");
			company.setStockEnlistmentSite("NSE");
			company.setCompanyCode(125);
			
			Company newcompany = new Company();
			newcompany.setCompanyCEO("CEO");
			newcompany.setCompanyName("CTS");
			newcompany.setCompanyWebsite("www.cognizant.com");
			newcompany.setStockEnlistmentSite("NSE");
			newcompany.setCompanyCode(125);
			
			
			when(companyService.updateCompany(newcompany)).thenReturn(false);
			
			mockMvc.perform(MockMvcRequestBuilders.put("/api/v1.0/market/company/put/{companycode}",125).contentType(MediaType.APPLICATION_JSON)
					.content(new ObjectMapper().writeValueAsString(company))).andExpect(MockMvcResultMatchers.status().isInternalServerError());

			
		}

	}

