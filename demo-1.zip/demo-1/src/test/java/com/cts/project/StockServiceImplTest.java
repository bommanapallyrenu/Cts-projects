package com.cts.project;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.project.Repository.StockRepository;
import com.cts.project.entity.Stock;
import com.cts.project.service.StockServiceImpl;

@AutoConfigureMockMvc
@SpringBootTest
public class StockServiceImplTest 
{	
	
			@Mock
			private StockRepository stockRepo;
			
			@InjectMocks
			private StockServiceImpl stockService;
			
			@Autowired
			private MockMvc mockMvc;
			
			@BeforeEach
			public void init()
			{
				MockitoAnnotations.openMocks(this);
				mockMvc = MockMvcBuilders.standaloneSetup(stockService).build();
			}

			Set<Stock> stockList = new HashSet<Stock>();
			
			@Test
			public void getAllStockSuccess() throws Exception
			{
				
				Stock stock=new Stock();
				stock.setCompany_code_fk(125);
				//stock.setDate_time(new Date("2022-10-27T15:03:34"));
				stock.setStockPrice(12.5);
				
				stockList.add(stock);
				when(stockRepo.getStockList(125)).thenReturn(stockList);
				
				Set<Stock> newList = stockService.getAllStocks(125);
				assertEquals(stockList, newList);
				
			}
			
			@Test
			public void getAllStockFailure() throws Exception
			{
				
				when(stockRepo.getStockList(125)).thenReturn(null);
				
				Set<Stock> newstockList = stockService.getAllStocks(125);
				assertNull(newstockList);
				
			}
			
			@Test
			public void addStockSuccess() throws Exception
			{
				Stock stock=new Stock();
				stock.setCompany_code_fk(125);
				//stock.setDate_time(new Date("2022-10-27T15:03:34"));
				stock.setStockPrice(12.5);
				
				stockList.add(stock);
				when(stockRepo.save(any())).thenReturn(stock);
				
				
				boolean c1 = stockService.addStock(stock);
				assertTrue(c1);
			}
			
			@Test
			public void addStockFailure() throws Exception
			{
				
				when(stockRepo.save(any())).thenReturn(null);
				
				boolean val = stockService.addStock(null);
				assertFalse(val);
			}
			
			@Test
			public void deleteStockSuccess() throws Exception
			{
				Stock stock=new Stock();
				stock.setCompany_code_fk(125);
				//stock.setDate_time(new Date("2022-10-27T15:03:34"));
				stock.setStockPrice(12.5);
				
				stockList.add(stock);
				
				stockRepo.deleteStockData(125);
				
				boolean c1 = stockService.deleteStock(125);
				assertTrue(c1);
			}

	}
