package com.cts.project;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.cts.project.entity.Company;
import com.cts.project.entity.Stock;


public class CompanyTest {
		
		
		@Test
		public void test01()
		{
			Company companyObj = Mockito.mock(Company.class);// creating the mock object
			
			when(companyObj.getCompanyName()).thenReturn(null);
			
			Company company = new Company();
			
			company.setCompanyName("Cognizant");
				 
			String companyname = company.getCompanyName();
			 
			 when(companyObj.getCompanyName()).thenReturn("Cognizant");
				 
			 assertEquals("Cognizant", companyname);
			
		}
		@Test
		public void test02()
		{
			Company companyObj = Mockito.mock(Company.class);// creating the mock object
			
			when(companyObj.getCompanyCEO()).thenReturn(null);
			
			Company company = new Company();
			
			company.setCompanyCEO("CEOxyz");
				 
			String companyceo = company.getCompanyCEO();
			 
			 when(companyObj.getCompanyName()).thenReturn("CEOxyz");
				 
			 assertEquals("CEOxyz", companyceo);
			
		}
		@Test
		public void test03()
		{
			Company companyObj = Mockito.mock(Company.class);// creating the mock object
			
			Company company = new Company();
			
			company.setCompanyWebsite("www.cognizant.com");
			
			 when(companyObj.getCompanyWebsite()).thenReturn(company.getCompanyWebsite());
				 
			 assertEquals(companyObj.getCompanyWebsite(), company.getCompanyWebsite());
			
		}
		
		@Test
		public void test04()
		{
			Company companyObj = Mockito.mock(Company.class);// creating the mock object
			
			Company company = new Company();
			
			company.setStockEnlistmentSite("NSE");;
			
			 when(companyObj.getStockEnlistmentSite()).thenReturn(company.getStockEnlistmentSite());
				 
			 assertEquals(companyObj.getStockEnlistmentSite(), company.getStockEnlistmentSite());
			
		}
	}
