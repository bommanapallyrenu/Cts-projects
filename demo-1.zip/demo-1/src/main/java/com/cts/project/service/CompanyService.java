package com.cts.project.service;

import java.util.List;
import java.util.Optional;

import com.cts.project.entity.Company;
import com.cts.project.exceptions.CompanyCodeAlreadyExistsException;

public interface CompanyService {

		
		List<Company> getAllCompanies();
		
		Optional<Company> getCompanyById(int companyCode);
		
		Company save(Company company) throws CompanyCodeAlreadyExistsException;
		
		boolean delete(int companyCode);
		
		boolean updateCompany(Company company);

}
