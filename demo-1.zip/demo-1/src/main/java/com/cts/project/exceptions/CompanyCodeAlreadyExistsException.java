package com.cts.project.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code=HttpStatus.CONFLICT, reason="The CompanyCode is already present in Database")
public class CompanyCodeAlreadyExistsException extends Exception
{

}