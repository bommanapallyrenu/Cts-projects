package com.cts.project.controller;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.project.entity.Company;
import com.cts.project.entity.Stock;
import com.cts.project.exceptions.CompanyCodeAlreadyExistsException;
import com.cts.project.service.CompanyServiceImpl;
import com.cts.project.service.StockService;

@Controller
@RequestMapping("/api/v1.0/market/company")
@RestController

public class CompanyController {
	
		@Autowired
	    private CompanyServiceImpl companyService;
		
		@Autowired
		private StockService stockservice;
	   
	    	@PostMapping(path = "/register", consumes = "application/json")
	    	public ResponseEntity<?> addCompany(@RequestBody Company company) throws CompanyCodeAlreadyExistsException {
	    		
	    		if(companyService.save(company)!=null) {
	    			
	    			return new ResponseEntity<Company>(company,HttpStatus.CREATED);
	    		}
				return new ResponseEntity<String>("Object is empty",HttpStatus.CONFLICT);
	    	}

	    	@GetMapping(path = "/info/{companycode}", produces = "application/json")
	    	public ResponseEntity<?> getCompany(@PathVariable int companycode) {
	    		
	    			Optional<Company> companydetails= companyService.getCompanyById(companycode);
		    		if (companydetails!=null) {
		    			return new ResponseEntity<Company>(companydetails.get(),HttpStatus.OK);
	    		}
		 
		   			return new ResponseEntity<String>("Company with this code is not found",HttpStatus.NO_CONTENT);
	    	
	    	}
	    
	    	
	    	@DeleteMapping(path = "/delete/{companycode}")
	    	public ResponseEntity<?> deleteCompanyById(@PathVariable int companycode) {
	    		
	    		if(stockservice.deleteStock(companycode)&companyService.delete(companycode)) {
	    			
	    			return new ResponseEntity<String>("Company Object Deleted Successfully",HttpStatus.NO_CONTENT);
		    	
	    		}
	    		else return new ResponseEntity<String>("Company Object Cannot be Deleted",HttpStatus.INTERNAL_SERVER_ERROR);
	    		
	    	}
	    	
	    	@GetMapping(path = "/getall", produces = "application/json")
	    	public ResponseEntity<?> getAllCompanies(){
	    		
	    		List<Company> companieslist= companyService.getAllCompanies();
	    		
	    		if(!companieslist.isEmpty()) {
	    			
	    			for(Company c : companieslist)
	    			{
	    				Set<Stock> stockList =stockservice.getAllStocks(c.getCompanyCode());
	    				c.setStockList(stockList);
	    			}
	    			return new ResponseEntity<List<Company>>(companieslist, HttpStatus.OK);
	    			
	    			//return MyResponse.generateCustomResponseFormat("Succesfully retrieved data!", HttpStatus.OK, bookList);
	    			
	    			/*CacheControl cacheControl = CacheControl.maxAge(30,TimeUnit.MINUTES);
	    			
	    			return ResponseEntity.ok().cacheControl(cacheControl)
	    			.body(MyResponse.generateCustomResponseFormat("Succesfully retrieved data!", HttpStatus.OK, bookList));*/		
	    		}	
	    			
	    		else	
	    			return new ResponseEntity<String>("companyList is empty", HttpStatus.NO_CONTENT);
	    		//return MyResponse.generateCustomResponseFormat("Could not retrieve data!", HttpStatus.CONFLICT,null);	
	    	}
	    	
	    	@PutMapping(path = "/put/{companycode}")
	    	public ResponseEntity<?> updateCompany(@PathVariable int companycode, @RequestBody Company company)
	    	{
	    		if(companyService.updateCompany(company))
	    		{
	    			return new ResponseEntity<>(company, HttpStatus.CREATED);
	    		}
	    		
	    		return new ResponseEntity<String>("Company record cannot be updated!", HttpStatus.INTERNAL_SERVER_ERROR);
	    	}
}
