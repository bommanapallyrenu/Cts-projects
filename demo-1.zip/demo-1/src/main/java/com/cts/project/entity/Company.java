package com.cts.project.entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Company {
	
	@Id
	private int companyCode;
	private String companyName;
	private String companyCEO;
	private  String companyWebsite;
	private double turnOver;
	private String stockEnlistmentSite;
	
	private Double stockPrice;

	@JsonIgnore
	@OneToMany(targetEntity= Stock.class)
	private Set<Stock> stockList;
	
	public Double getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(Double stockPrice) {
		this.stockPrice = stockPrice;
	}
	
	public Set<Stock> getStockList() {
		return stockList;
	}
	public void setStockList(Set<Stock> stockList) {
		this.stockList = stockList;
	}
	public int getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyCEO() {
		return companyCEO;
	}
	public void setCompanyCEO(String companyCEO) {
		this.companyCEO = companyCEO;
	}
	public String getCompanyWebsite() {
		return companyWebsite;
	}
	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}
	public double getTurnOver() {
		return turnOver;
	}
	public void setTurnOver(double turnOver) {
		this.turnOver = turnOver;
	}
	public String getStockEnlistmentSite() {
		return stockEnlistmentSite;
	}
	public void setStockEnlistmentSite(String stockEnlistmentSite) {
		this.stockEnlistmentSite = stockEnlistmentSite;
	}
	
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Company [companyCode=" + companyCode + ", companyName=" + companyName + ", companyCEO=" + companyCEO
				+ ", companyWebsite=" + companyWebsite + ", turnOver=" + turnOver + ", stockEnlistmentSite="
				+ stockEnlistmentSite + "]";
	}
	public Company(int companyCode, String companyName, String companyCEO, String companyWebsite, double turnOver,
			String stockEnlistmentSite) {
		super();
		this.companyCode = companyCode;
		this.companyName = companyName;
		this.companyCEO = companyCEO;
		this.companyWebsite = companyWebsite;
		this.turnOver = turnOver;
		this.stockEnlistmentSite = stockEnlistmentSite;
	}
	

}
