package com.cts.project.controller;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.project.entity.Company;
import com.cts.project.entity.Stock;
import com.cts.project.service.CompanyService;
import com.cts.project.service.StockService;

@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StockController {
	
		@Autowired
		private CompanyService companyservice;
		
		@Autowired
		private StockService stockservice;
		
		@PostMapping("/add/{companycode}")
		public ResponseEntity<?> addStock(@PathVariable("companycode") int companycode, @RequestBody Stock stock)
		{
			Company existCompany = companyservice.getCompanyById(companycode).get();
			if(existCompany !=null&&(companycode==stock.getCompany_code_fk()))
			{
				//Company table
				existCompany.setStockPrice(stock.getStockPrice());
				// stock table
				stock.setStockPrice(stock.getStockPrice());
				stock.setCompany_code_fk(stock.getCompany_code_fk());
				stock.setDate_time(stock.getDate_time());
						
				if(companyservice.updateCompany(existCompany) && stockservice.addStock(stock)) {
						
					return new ResponseEntity<Stock>(stock, HttpStatus.CREATED);
				}
				
			}
				
				return new ResponseEntity<>("Company Stock price cannot be added", HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
		
		@GetMapping("/getAllStocks")
		public ResponseEntity<?> getAllStocks(@RequestParam("companycode") int companycode)  
		{
		     Set<Stock> stockList = stockservice.getAllStocks(companycode);
		      if(stockList != null && !stockList.isEmpty())
		      {
		        CacheControl cache = CacheControl.maxAge(30, TimeUnit.MINUTES);
		        return new ResponseEntity<>(stockList, HttpStatus.OK);
		      }
		      
		       return new ResponseEntity<>("Stocks not available", HttpStatus.NO_CONTENT);
		}

	}

