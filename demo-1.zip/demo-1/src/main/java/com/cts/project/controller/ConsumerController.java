package com.cts.project.controller;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.project.entity.Userdto;

	@RestController
	public class ConsumerController 
	{
		@PostMapping("/consumeUser")
		public ResponseEntity<?> consumeUser(@RequestParam("id")int id,@RequestParam("username")String username,
				@RequestParam("password")String password ) throws Exception
		{
			Userdto userdto=new Userdto(id,username,password); //parameterized constructor
		
			RestTemplate restTemplate = new RestTemplate();
			
			String baseUrl = "http://localhost:8082/auth/user/registerUser";
			
			ResponseEntity<String> response = null;
			
			try {
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<Userdto> httpEntity = new HttpEntity<Userdto>(userdto, headers);

			ResponseEntity<Userdto> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.POST, httpEntity,
					Userdto.class);
			System.out.println(responseEntity.getBody());
			System.out.println(responseEntity.getHeaders()+"-->"+ responseEntity.getStatusCodeValue());
			return new ResponseEntity<>(responseEntity, HttpStatus.OK);
		
			
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			return new ResponseEntity<String>("response object is null", HttpStatus.NO_CONTENT);
			
		}
		
		/*@PostMapping("/consumeUser")
		public ResponseEntity<?> consumeUser(@RequestBody Userdto user ) throws Exception
		{
		
			RestTemplate restTemplate = new RestTemplate();
			
			String baseUrl = "http://localhost:8082/auth/user/registerUser";
			
			ResponseEntity<String> response = null;
			
			try {
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			//URI uri = new URI("http://localhost:8080/employee");
			/*User objEmp = new User();
			objEmp.setName("Krishna");
			objEmp.setCity("Noida");*/

			/*HttpEntity<Userdto> httpEntity = new HttpEntity<Userdto>(user, headers);

			//RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<Userdto> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.POST, httpEntity,
					Userdto.class);
			System.out.println(responseEntity.getBody());
			System.out.println(responseEntity.getHeaders()+"-->"+ responseEntity.getStatusCodeValue());
			return new ResponseEntity<>(responseEntity, HttpStatus.OK);
		
			
		}
		/*	catch(Exception e)
			{
				e.printStackTrace();
			}
			
			return new ResponseEntity<String>("response object is null", HttpStatus.NO_CONTENT);
			
		}*/
		
		@PostMapping("/consumeUserlogin")
		public ResponseEntity<?> consumeUserlogin(@RequestParam("username")String username,
				@RequestParam("password")String password) throws Exception
		{
			Userdto userdto=new Userdto(username,password); //parameterized constructor
			
		
			RestTemplate restTemplate = new RestTemplate();
			
			String baseUrl = "http://localhost:8082/auth/user/login";
			
			ResponseEntity<String> response = null;
			
			try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<?> httpEntity = new HttpEntity<>(userdto, headers);

			ResponseEntity<?> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.POST, httpEntity,String.class);
			System.out.println(responseEntity.getBody());
			System.out.println(responseEntity.getHeaders()+"-->"+ responseEntity.getStatusCodeValue());
			return new ResponseEntity<>(responseEntity, HttpStatus.OK);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			return new ResponseEntity<String>("response object is null", HttpStatus.NO_CONTENT);
			
		}
		
		
		private static HttpEntity<?> getHeader() throws Exception
		{
			HttpHeaders headers = new HttpHeaders();
			//headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
			 headers.set("Content-Type", "application/json");
			//headers.setContentType(MediaType.APPLICATION_JSON);
			return new HttpEntity<>(headers);
		}

	}


