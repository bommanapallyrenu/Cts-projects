package com.cts.project.service;

import java.util.Set;

import com.cts.project.entity.Stock;

public interface StockService {
	
	public Set<Stock> getAllStocks(int companyCode);
	
	public boolean deleteStock(int Companycode);
	
	public boolean addStock(Stock stock);
	

}
