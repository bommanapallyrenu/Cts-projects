package com.cts.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.project.Repository.CompanyRepository;
import com.cts.project.entity.Company;
import com.cts.project.exceptions.CompanyCodeAlreadyExistsException;

@Service
public class CompanyServiceImpl implements CompanyService{
	

		@Autowired
		private CompanyRepository companyRepository;
		
		@Override
		public List<Company> getAllCompanies(){
			
			List<Company> companyList=companyRepository.findAll();
			if(companyList!=null && companyList.size()>0)
			{
				return companyList;
			}
			else
			{
				return null;
			}
		}
		
		@Override
		public Optional<Company> getCompanyById(int companycode){
			
			Optional<Company> companydetails=companyRepository.findById(companycode);
			
			if(companydetails.isPresent()) {
				return companydetails;	
			}
				return null;
	
		}
		
		@Override
		public Company save(Company company) throws CompanyCodeAlreadyExistsException{
			
			Optional<Company> companyobj=companyRepository.findById(company.getCompanyCode());
			
			if(companyobj.isPresent()) {
				throw new CompanyCodeAlreadyExistsException();
			}
			
			return companyRepository.save(company);
		}
		
		@Override
		public boolean delete(int companyCode){
			
			if(companyRepository.findById(companyCode).isPresent()) {
			
			companyRepository.deleteById(companyCode);
			return true;	
			}
			return false;
		}
		
		@Override
		public boolean updateCompany(Company company) 
		{
			Company newdetails = companyRepository.getById(company.getCompanyCode());
			
			if(newdetails !=null)
			{
				newdetails.setCompanyCEO(company.getCompanyCEO());
				newdetails.setCompanyName(company.getCompanyName());
				newdetails.setCompanyWebsite(company.getCompanyWebsite());
				newdetails.setStockEnlistmentSite(company.getStockEnlistmentSite());
				newdetails.setTurnOver(company.getTurnOver());
				companyRepository.saveAndFlush(newdetails);
				return true;
			}
			return false;
			
		}
	}

