package com.cts.project.entity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;

@Entity
public class Stock 
{
	@Id
	@GeneratedValue
	private int transactionId;
	
	Double stockPrice;
	
	Date date_time;
	
	private int company_code_fk;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public Double getStockPrice() {
		return stockPrice;
	}

	public void setStockPrice(Double stockPrice) {
		this.stockPrice = stockPrice;
	}

	public Date getDate_time() {
		return date_time;
	}

	public void setDate_time(Date date_time) {
		this.date_time = date_time;
	}

	public int getCompany_code_fk() {
		return company_code_fk;
	}

	public void setCompany_code_fk(int company_code_fk) {
		this.company_code_fk = company_code_fk;
	}

	@PrePersist
	public void setTimeStamp()
	{
		if(this.date_time == null)
		{
			SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			//timeFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); //IST
		}
	}


}














